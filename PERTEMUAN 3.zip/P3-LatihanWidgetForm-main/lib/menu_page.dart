import 'package:flutter/material.dart';
import 'column_widget.dart';
import 'row_widget.dart';
import 'ui/produk_form.dart';

class MenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Main Menu")),
      body: ListView(
        children: [
          ListTile(
            title: Text("Widget Column"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ColumnWidget()),
              );
            },
          ),
          ListTile(
            title: Text("Widget Row"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RowWidget()),
              );
            },
          ),
          ListTile(
            title: Text("Form Produk"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProdukForm()),
              );
            },
          ),
        ],
      ),
    );
  }
}
