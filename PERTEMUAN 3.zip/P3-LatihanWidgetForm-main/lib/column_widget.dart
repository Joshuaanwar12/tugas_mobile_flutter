import 'package:flutter/material.dart';

class ColumnWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Widget Column")),
      body: Column(
        children: [Text("colomn 1"), Text("colomn 2"), Text("colomn 3")],
      ),
    );
  }
}
