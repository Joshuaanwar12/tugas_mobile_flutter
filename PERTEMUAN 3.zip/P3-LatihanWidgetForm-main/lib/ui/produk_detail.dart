import 'package:flutter/material.dart';

class ProdukDetail extends StatelessWidget {
  final String kode;
  final String nama;
  final String harga;

  ProdukDetail({required this.kode, required this.nama, required this.harga});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Detail Produk")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Kode: $kode"),
            Text("Nama: $nama"),
            Text("Harga: $harga"),
          ],
        ),
      ),
    );
  }
}
