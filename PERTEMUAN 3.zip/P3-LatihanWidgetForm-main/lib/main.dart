import 'package:flutter/material.dart';
import 'column_widget.dart';
import 'row_widget.dart';
import '/ui/produk_form.dart';
import 'menu_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Belajar Flutter', home: MenuPage());
  }
}
