import 'package:flutter/material.dart';

class RowWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Widget Row")),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [Text("row 1"), Text("row 2"), Text("row 3")],
      ),
    );
  }
}
